package org.genpact.veta.fileCopyData.service;


//import org.genpact.veta.weibulData.dao.WeiBullDataDAO;
//import org.genpact.veta.weibulData.dto.WeiBullEngineDataVO;
//import org.genpact.veta.weibulData.dto.WeiBullEngineRequestWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.genpact.veta.fileCopyData.util.CSVLoader;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileOutputStream;

import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;
@CrossOrigin
@Controller
public class fileUploadService {

	@Autowired
    private JdbcTemplate jdbcTemplate;
	//@Autowired
  //  private WeiBullDataDAO weiBullDataDAO;
	private String UPLOAD_DIRECTORY = "target";
	private static String JDBC_CONNECTION_URL="jdbc:postgresql://localhost:5432/postgres";
	String check = "running";
	
	 @Autowired
	    ServletContext servletContext;
	
	@CrossOrigin
	@RequestMapping(value = "/getData", method=RequestMethod.POST)
	public @ResponseBody String getWeiBullEngineDataResponse(@RequestParam(value="file", required=true) MultipartFile f){
		 
		BufferedReader br = null;
		String uploadPath = System.getProperty("user.dir");
		  // System.out.println("Current working directory : " + uploadPath);

		if (f == null) {
	        System.out.println("File is null");
	        
	    } else{
	    	//System.out.println(f.getOriginalFilename());
	    }

		
		System.out.println("welcome");
		
	   String check = "running";
		//String weiBullEngineDataVOList = weiBullDataDAO.rest();
	    uploadPath = uploadPath + File.separator + UPLOAD_DIRECTORY ;
		//String contextPath = servletContext.getRealPath(File.separator);
	   //System.out.println(uploadPath);
	  File uploadDir = new File(uploadPath);
       if (!uploadDir.exists()) {
           uploadDir.mkdir();
       }
       uploadPath = uploadPath + File.separator + f.getOriginalFilename();
       if (f.getSize() > 0) {
    	   System.out.println(f.getSize());
    	   File savedFile = new File(uploadPath);
    	   OutputStream out = null;
    	   try {
				out = new FileOutputStream(savedFile);
			    out.write(f.getBytes());
			}catch (Exception ex) {
			 
			    
		}finally {
		    // Release resource
		    if (out != null) {
			try {
				out.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				
			}
		    }
       }
       
       }
       
       try{
    	   Connection connection=jdbcTemplate.getDataSource().getConnection();
   		CSVLoader csvLoader = new CSVLoader(connection);
   		csvLoader.loadCSV(uploadPath, "customer", true);
   		} catch (Exception e){
   			e.printStackTrace();
   		}
	    // TODO: call persistence layer to update
	    return UPLOAD_DIRECTORY;
	}
	
	
	/*private static Connection getCon(){
		Connection connection= null;
		try{
			Class.forName("org.postgresql.Driver");
			//connection = DriverManager.getConnection("jdbc:postgresql://hostname:port/dbname","username", "password");
			connection=DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres", "postgre");
			//connection=jdbcTemplate.getDataSource().getConnection();
		} catch(ClassNotFoundException e){
			e.printStackTrace();
		} catch (SQLException e){
			e.printStackTrace();
		}
		return connection;
	}*/



}
