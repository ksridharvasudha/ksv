/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  javax.inject.Singleton
 *  javax.ws.rs.Consumes
 *  javax.ws.rs.DELETE
 *  javax.ws.rs.DefaultValue
 *  javax.ws.rs.FormParam
 *  javax.ws.rs.GET
 *  javax.ws.rs.POST
 *  javax.ws.rs.PUT
 *  javax.ws.rs.Path
 *  javax.ws.rs.PathParam
 *  javax.ws.rs.Produces
 *  javax.ws.rs.QueryParam
 *  javax.ws.rs.core.MultivaluedMap
 *  javax.ws.rs.core.Response
 *  javax.ws.rs.core.Response$ResponseBuilder
 */
package com.intuit.training;

import com.intuit.training.Employee;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TreeMap;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

@Path(value="/employee")
@Singleton
public class EmployeeResource {
    private TreeMap<Integer, Employee> employeeList = new TreeMap();

    public EmployeeResource() {
        this.employeeList.put(101, new Employee(101, "Rakesh", "Developer"));
        this.employeeList.put(102, new Employee(102, "Arjun", "Accountant"));
        this.employeeList.put(103, new Employee(103, "Vijayan", "Architect"));
    }

    @GET
    @Produces(value={"application/json"})
    public List<Employee> getAllEmployees() {
        ArrayList<Employee> list = new ArrayList<Employee>(this.employeeList.values());
        return list;
    }

    @Path(value="/{id}")
    @GET
    @Produces(value={"application/json"})
    public Employee findEmployee(@PathParam(value="id") int empId) {
        return this.employeeList.get(empId);
    }

    @POST
    @Produces(value={"text/plain"})
    @Consumes(value={"application/json"})
    public String addEmployee(Employee e) {
        int nextId = this.employeeList.lastKey() + 1;
        e.setId(nextId);
        this.employeeList.put(nextId, e);
        return "Employee with Id " + nextId + " successfully  added";
    }

    @Path(value="/{id}")
    @PUT
    @Produces(value={"text/plain"})
    @Consumes(value={"application/json"})
    public Response updateEmployee(Employee e, @PathParam(value="id") int id) throws FileNotFoundException {
        Employee emp = this.employeeList.get(id);
        if (emp == null) {
            throw new FileNotFoundException("No such employee");
        }
        emp.setName(e.getName());
        emp.setDesignation(e.getDesignation());
        return Response.ok().entity((Object)("Employee with " + id + " successfully updated")).build();
    }

    @Path(value="/{id}")
    @DELETE
    @Produces(value={"text/plain"})
    public String removeEmployee(@PathParam(value="id") int id) {
        this.employeeList.remove(id);
        return "Employee with " + id + " successfully removed";
    }

    @POST
    @Consumes(value={"application/json"})
    @Produces(value={"text/plain"})
    @Path(value="/multiple")
    public String addEmployees(List<Employee> employees) {
        String resp = "";
        for (Employee employee : employees) {
            resp = String.valueOf(resp) + "\n" + this.addEmployee(employee);
        }
        return resp;
    }

    @Path(value="/throughForm")
    @GET
    @Produces(value={"text/html"})
    public String getEmployeeDetails(@QueryParam(value="emp_id") @DefaultValue(value="101") int id) {
        String resp = "<html><body>";
        Employee employee = this.employeeList.get(id);
        resp = String.valueOf(resp) + "<b>Name: " + employee.getName();
        resp = String.valueOf(resp) + "<br>Designation: " + employee.getDesignation();
        resp = String.valueOf(resp) + "</b></body></html>";
        return resp;
    }

    @Path(value="/throughForm")
    @Produces(value={"text/html"})
    @POST
    public String addEmployee(@FormParam(value="emp_name") String empName, @FormParam(value="designation") String desgination) {
        Employee e = new Employee();
        e.setName(empName);
        e.setDesignation(desgination);
        String resp = this.addEmployee(e);
        return "<html><body>" + resp + "</body></html>";
    }

    @Path(value="/throughFormMap")
    @Produces(value={"text/html"})
    @POST
    @Consumes(value={"application/x-www-form-urlencoded"})
    public String addEmployee(MultivaluedMap<String, String> parameters) {
        Employee e = new Employee();
        e.setName((String)((List)parameters.get((Object)"emp_name")).get(0));
        e.setDesignation((String)((List)parameters.get((Object)"designation")).get(0));
        String resp = this.addEmployee(e);
        return "<html><body>" + resp + "</body></html>";
    }
}