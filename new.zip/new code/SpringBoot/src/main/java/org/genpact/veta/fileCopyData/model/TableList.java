package main.java.org.genpact.veta.fileCopyData.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
@XmlAccessorType(XmlAccessType.FIELD)

@XmlRootElement(name = "TableList")
public class TableList {
	private List<Table> tl;

	public List<Table> getTl() {
		return tl;
	}

	public void setTl(List<Table> tl) {
		this.tl = tl;
	}

	public TableList() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TableList(List<Table> tl) {
		super();
		this.tl = tl;
	}
	

}
