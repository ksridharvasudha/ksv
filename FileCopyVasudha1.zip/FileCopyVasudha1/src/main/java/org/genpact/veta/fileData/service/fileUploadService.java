package org.genpact.veta.fileData.service;


//import org.genpact.veta.weibulData.dao.WeiBullDataDAO;
//import org.genpact.veta.weibulData.dto.WeiBullEngineDataVO;
//import org.genpact.veta.weibulData.dto.WeiBullEngineRequestWrapper;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;








import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
@CrossOrigin
@Controller
public class fileUploadService {

	@Autowired
    private JdbcTemplate jdbcTemplate;

	private String UPLOAD_DIRECTORY = "target";
	private static String JDBC_CONNECTION_URL="jdbc:postgresql://localhost:3120/postgres";
	String check = "running";
	
	 @Autowired
	    ServletContext servletContext;
	
	 @CrossOrigin
		@RequestMapping(value = "/insertData/{tablename}", method=RequestMethod.POST,produces={"text/plain"},headers="Content-Type=application/x-www-form-urlencoded , application/xml, application/json")
		public @ResponseBody String insetExcelsheetDataResponse(@PathVariable(value="tablename") String tablename,@RequestBody List<Object> t){     
		 Connection connection=null;
		 Statement st=null;
		 try{
	    	    connection=jdbcTemplate.getDataSource().getConnection();
	   			       
	    	    st=connection.createStatement();  		    	   
	       Iterator i=t.iterator();
	       while(i.hasNext())
	       {
	    	   LinkedHashMap l=(LinkedHashMap) i.next();
	    	   Collection l1= l.values();
	    	   
	    	   System.out.println(l);
	    	   
	    	   String query="insert into "+tablename+" values(";
	    	   Iterator li=l1.iterator();
	    	   while(li.hasNext())
	    	   {
	    		   query=query+"'"+li.next()+"',";
	    		   //System.out.println(i1.next());
	    	   }
	    	   System.out.println(query);
	    	  
	    		   query=query.substring(0, query.length() - 1);
	    	       
	    	     
	    	   query=query+")";
	    	   System.out.println(query);
	    	   st.executeUpdate(query);   
	       }
		 } catch (Exception e){
	   			e.printStackTrace();
	   			return e.toString();
	   		}
	      
		    // TODO: call persistence layer to update
		    return "Inserted Successfully";
		}
	 
	 
	 @CrossOrigin
		@RequestMapping(value = "/updateTable/{tablename}", method=RequestMethod.POST,produces={"text/plain"},headers="Content-Type=application/x-www-form-urlencoded , application/xml, application/json")
		public @ResponseBody String updateExcelSheetDataResponse(@PathVariable(value="tablename") String tablename,@RequestBody List<Object> t){     
		 Connection connection=null;
		 Statement st=null;
		 try{
	    	    connection=jdbcTemplate.getDataSource().getConnection();
	   			       
	    	    st=connection.createStatement();  	
	    	    st.executeUpdate("delete from "+tablename);
	       Iterator i=t.iterator();
	       while(i.hasNext())
	       {
	    	   LinkedHashMap l=(LinkedHashMap) i.next();
	    	   Collection l1= l.values();
	    	   
	    	   System.out.println(l);
	    	   
	    	   String query="insert into "+tablename+" values(";
	    	   Iterator li=l1.iterator();
	    	   while(li.hasNext())
	    	   {
	    		   query=query+"'"+li.next()+"',";
	    		   //System.out.println(i1.next());
	    	   }
	    	   System.out.println(query);
	    	  
	    		   query=query.substring(0, query.length() - 1);
	    	       
	    	     
	    	   query=query+")";
	    	   System.out.println(query);
	    	   st.executeUpdate(query);   
	       }
		 } catch (Exception e){
	   			e.printStackTrace();
	   			return e.toString();
	   		}
	      
		    // TODO: call persistence layer to update
		    return "upload Successfully";
		}
	 
	 
	 @CrossOrigin
		@RequestMapping(value = "/getTable/{tablename}", method=RequestMethod.GET)
		public @ResponseBody List<Map<String, Object>> getExcelSheetDataResponse(@PathVariable(value="tablename") String tablename) throws SQLException{     
		 Connection connection=null;
		 Statement st=null;
		 ResultSet rs=null;
		 try{
	    	    connection=jdbcTemplate.getDataSource().getConnection();
	   			       
	    	    st=connection.createStatement();  	
	    	    rs=st.executeQuery("select * from "+tablename);
	    	    
	    	    
	    	    //return getEntitiesFromResultSet(rs);
	      
		 } catch (Exception e){
	   			e.printStackTrace();
	   			//return e.toString();
	   		}
		 return getEntitiesFromResultSet(rs);
		    // TODO: call persistence layer to update
		    //return "upload Successfully";
		}
	 
	 
	 protected List<Map<String, Object>> getEntitiesFromResultSet(ResultSet resultSet) throws SQLException {
	        ArrayList<Map<String, Object>> entities = new ArrayList<>();
	        while (resultSet.next()) {
	            entities.add(getEntityFromResultSet(resultSet));
	        }
	        return entities;
	    }

	    protected Map<String, Object> getEntityFromResultSet(ResultSet resultSet) throws SQLException {
	        ResultSetMetaData metaData = resultSet.getMetaData();
	        int columnCount = metaData.getColumnCount();
	        Map<String, Object> resultsMap = new HashMap<>();
	        for (int i = 1; i <= columnCount; ++i) {
	            String columnName = metaData.getColumnName(i).toLowerCase();
	            Object object = resultSet.getObject(i);
	            resultsMap.put(columnName, object);
	        }
	        return resultsMap;
	    }
}


