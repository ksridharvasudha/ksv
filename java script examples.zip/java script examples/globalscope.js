<!DOCTYPE html>
<html>
<body>

<p>A local variable can only be accessed from within the function where it was declared.</p>

<p id="demo"></p>

<script>
(function show(){
'use strict';
var a=window.b=5;
})();
console.log(b);
alert("b="+b+"  a="+a);
</script>

</body>
</html>
