
package com.soap.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "id",
    "name",
    "designation"
})
@XmlRootElement(name = "Employee")
@Entity
@Table(name="EMPLOYEE")
public class Employee {

    @XmlElement(required = true)
    @Id
    @Column(name="id")
    protected int id;
    @XmlElement(required = true)
    @Column(name="name")
    protected String name;
    @XmlElement(required = true)
    @Column(name="designation")
    protected String designation;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Employee(int id, String name, String designation) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	 @Override
	public Object clone() throws CloneNotSupportedException {
	        return super.clone();
	    }
}


