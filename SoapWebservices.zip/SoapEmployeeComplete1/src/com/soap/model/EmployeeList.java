package com.soap.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)

@XmlRootElement(name = "EmployeeList")
public class EmployeeList {
	private List<Employee> employee;

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

	public EmployeeList(List<Employee> employee) {
		super();
		this.employee = employee;
	}

	public EmployeeList() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
