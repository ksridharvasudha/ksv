package com.soap.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.soap.model.Employee;
import com.soap.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
	 
    private static Map<Integer,Employee> persons = new HashMap<Integer,Employee>();
    Session session=null;
    public EmployeeServiceImpl()
    {
    	Configuration configuration=new Configuration().configure();
		SessionFactory factory=configuration.buildSessionFactory();
		 session=factory.openSession();
    }
    @Override
    public boolean addEmployee(Employee p) {
        if(persons.get(p.getId()) != null) return false;
        persons.put(p.getId(), p);
        return true;
    }
 
    @Override
    public boolean deleteEmployee(int id) {
        if(persons.get(id) == null) return false;
        persons.remove(id);
        return true;
    }
 
    @Override
    public Employee getEmployee(int id) {
        return persons.get(id);
    }
 
    @Override
    public String getService() {
        return "service";
    }
    
    @Override
    public Employee[] getAllEmployees() {
Query query = session.createQuery("FROM  Employee");
		
		List<Employee> list=query.list();
		
        
        Employee[] p = new Employee[list.size()];
        int i=0;
        
        for(Employee array:list){
			Employee e=new Employee();
			
			e.setId(array.getId());
			e.setName(array.getName());
			e.setDesignation(array.getDesignation());
			
			
				p[i]=new Employee();
				p[i]=e;
			
			i++;
		}
                return p;
    }
    
   /* public EmployeeList getAllEmployees() {
    Query query = session.createQuery("FROM  Employee");
	
	List<Employee> list=query.list();
	int id=list.size();
	ArrayList<Employee> alist = new ArrayList<Employee>();
	for(Employee array:list){
		Employee e=new Employee();
		
		e.setId(array.getId());
		e.setName(array.getName());
		e.setDesignation(array.getDesignation());
		
		alist.add(e);
		
	}
	EmployeeList elist=new EmployeeList(alist);
    return elist;
    }*/
    
 
}