package com.soap.service;

import com.soap.model.Employee;
import com.soap.model.EmployeeList;

public interface EmployeeService {
	 
   
	boolean deleteEmployee(int id);

	boolean addEmployee(Employee p);

	//EmployeeList getAllEmployees();

	Employee getEmployee(int id);

	Employee[] getAllEmployees();

	String getService();
}