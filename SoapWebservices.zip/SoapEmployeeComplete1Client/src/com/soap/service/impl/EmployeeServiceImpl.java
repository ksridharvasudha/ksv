/**
 * EmployeeServiceImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.soap.service.impl;

public interface EmployeeServiceImpl extends java.rmi.Remote {
    public java.lang.String getService() throws java.rmi.RemoteException;
    public com.soap.model.Employee[] getAllEmployees() throws java.rmi.RemoteException;
    public boolean deleteEmployee(int id) throws java.rmi.RemoteException;
    public boolean addEmployee(com.soap.model.Employee p) throws java.rmi.RemoteException;
    public com.soap.model.Employee getEmployee(int id) throws java.rmi.RemoteException;
}
