/**
 * EmployeeServiceImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.soap.service.impl;

public interface EmployeeServiceImplService extends javax.xml.rpc.Service {
    public java.lang.String getEmployeeServiceImplAddress();

    public com.soap.service.impl.EmployeeServiceImpl getEmployeeServiceImpl() throws javax.xml.rpc.ServiceException;

    public com.soap.service.impl.EmployeeServiceImpl getEmployeeServiceImpl(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
