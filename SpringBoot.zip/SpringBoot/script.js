var app = angular.module('myApp', []);
/*app.config(['$httpProvider', function($httpProvider) {
	$httpProvider.defaults.useXDomain = true;
	$httpProvider.defaults.withCredentials = true;
	delete $httpProvider.defaults.headers.common["X-Requested-With"];
	$httpProvider.defaults.headers.common["Accept"] = "application/json";
	$httpProvider.defaults.headers.common["Content-Type"] = "application/json";
}
]);*/
app.controller("myCtrl",function($scope,$http)
		{
	$scope.data="hello";
	
	$http(
			{
			type:"GET",
			url:"http://localhost:8080/service",
			 headers:
				 {
				 "Content-Type": "application/x-www-form-urlencoded"
				 },
				 transformResponse: [function (data) {
				      // Do whatever you want!
					 console.log(data);
				      return data;
				  }]
			}
		).success(function(result)
				{
			console.log("hitted");
			$scope.data=result;
				}).error(function()
						{
					console.log("not hitted");
						})
		});




