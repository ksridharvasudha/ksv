var app = angular.module('myApp', []);

 
app.controller("AddEmp",function($scope,$http)
		{
	var emp={"id":$scope.empId,"name":$scope.empName,"designation":$scope.designation};
	
	$scope.addEmployee=function(){
		
		/*REQUEST Body Procedure*/
		/*$http({
			url:"http://localhost:8080/addEmployee/",
			method:"POST",
			data:emp
			
		}).
		success(function(result)
				{
			console.log(result);
				}).error(function(error)
						{
					console.log(error);
						})*/
		/*Url base procedure*/
		/*var url=""*/
		$http({
			url:"http://localhost:8080/addEmployee/"+$scope.empId+"/"+$scope.empName+"/"+$scope.designation+"/",
			method:"POST",
			
			
		}).
		success(function(result)
				{
			console.log(result);
				}).error(function(error)
						{
					console.log(error);
						})
  
	}
		});
	

